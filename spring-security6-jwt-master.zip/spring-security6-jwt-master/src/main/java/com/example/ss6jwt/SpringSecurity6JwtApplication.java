package com.example.ss6jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity6JwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurity6JwtApplication.class, args);
	}

}
