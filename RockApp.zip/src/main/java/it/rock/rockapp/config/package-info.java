/**
 * Spring Framework configuration files.
 */
package it.rock.rockapp.config;
