/**
 * Spring Security configuration.
 */
package it.rock.rockapp.security;
