/**
 * Spring Data JPA repositories.
 */
package it.rock.rockapp.repository;
