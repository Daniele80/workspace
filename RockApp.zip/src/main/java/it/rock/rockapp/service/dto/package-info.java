/**
 * Data Transfer Objects.
 */
package it.rock.rockapp.service.dto;
