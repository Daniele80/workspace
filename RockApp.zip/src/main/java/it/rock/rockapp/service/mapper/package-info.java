/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package it.rock.rockapp.service.mapper;
