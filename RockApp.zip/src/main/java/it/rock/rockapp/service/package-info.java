/**
 * Service layer beans.
 */
package it.rock.rockapp.service;
