/**
 * View Models used by Spring MVC REST controllers.
 */
package it.rock.rockapp.web.rest.vm;
