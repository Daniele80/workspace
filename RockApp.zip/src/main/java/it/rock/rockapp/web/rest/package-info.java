/**
 * Spring MVC REST controllers.
 */
package it.rock.rockapp.web.rest;
