/**
 * JPA domain objects.
 */
package it.rock.rockapp.domain;
