package it.rock.rockapp.cucumber;

import io.cucumber.junit.platform.engine.Cucumber;
import it.rock.rockapp.IntegrationTest;

@Cucumber
@IntegrationTest
class CucumberIT {}
