# spring-jwt-authentication
Sample project for Spring Security JWT Authentication
### Follow our written tutorial here: [Spring Security JWT Authentication Tutorial](https://www.codejava.net/frameworks/spring-boot/spring-security-jwt-authentication-tutorial)
### Watch coding in action on YouTube: [Spring Security JWT Authentication Tutorial](https://youtu.be/S7jV6di6Pl0)
