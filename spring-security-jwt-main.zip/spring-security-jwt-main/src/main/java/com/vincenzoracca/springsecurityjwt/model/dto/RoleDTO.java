package com.vincenzoracca.springsecurityjwt.model.dto;

import lombok.Data;

@Data
public class RoleDTO {

    private String roleName;
}
