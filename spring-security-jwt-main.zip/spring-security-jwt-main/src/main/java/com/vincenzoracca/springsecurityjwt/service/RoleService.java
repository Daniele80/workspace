package com.vincenzoracca.springsecurityjwt.service;

import com.vincenzoracca.springsecurityjwt.model.entity.RoleEntity;

public interface RoleService {

    RoleEntity save(RoleEntity roleEntity);

}
